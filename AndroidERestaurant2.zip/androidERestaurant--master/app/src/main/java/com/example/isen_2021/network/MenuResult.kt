package com.example.isen_2021.network

class MenuResult(val data: List<Category>) {
}