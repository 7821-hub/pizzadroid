package com.example.isen_2021.network

import java.io.Serializable

class Price(val price: String): Serializable {}